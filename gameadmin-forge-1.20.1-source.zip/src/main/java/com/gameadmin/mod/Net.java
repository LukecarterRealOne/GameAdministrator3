package com.gameadmin.mod;

import com.gameadmin.mod.client.ClientHooks;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Supplier;

/** Every network message of the mod, and the channel they travel on. */
public final class Net {
    private Net() {}

    public static final String PROTOCOL = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(GameAdminMod.MOD_ID, "main"), () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    // ------------------------------------------------------------ client -> server

    /** Cast ability #n. */
    public record Cast(int ability) {}

    /** Turn flight on or off. */
    public record FlightToggle(boolean enable) {}

    /** Game mode (0 survival, 1 creative, 2 adventure, 3 spectator) or tool (4 = give command blocks). */
    public record Power(int id) {}

    /** Set a game rule (index into Powers.RULES) on or off. */
    public record Rule(int rule, boolean value) {}

    /** Run any command from the command line. */
    public record RunCommand(String command) {}

    /** Edit a command block from survival. flags: bits 0-1 type, bit 2 conditional, bit 3 always active. */
    public record CommandBlockEdit(int x, int y, int z, String command, int flags) {}

    /** Toggle passive 0..4. -1 just asks the server to send the current state. */
    public record PassiveToggle(int id) {}

    // ------------------------------------------------------------ server -> client

    /** Result of a cast. status 0 = cast (value = how many things it affected), 1 = on cooldown (value = ms left). */
    public record Feedback(int ability, int status, int value) {
        public static final int CAST = 0;
        public static final int COOLDOWN = 1;
    }

    /** Flight is now on or off. */
    public record FlightState(boolean on) {}

    /** Bitmask of the passives that are on. */
    public record PassiveState(int mask) {}

    /** What you are adapting to (a mob id or a damage kind like "lava") and how far along (0 to 5). */
    public record Adapt(String mob, int level) {}

    /** A short message for the player's screen. */
    public record Notice(String text, int rgb) {}

    // ------------------------------------------------------------ registration

    public static void register() {
        int id = 0;

        CHANNEL.registerMessage(id++, Cast.class,
                (m, b) -> b.writeInt(m.ability()), b -> new Cast(b.readInt()),
                toServer((p, m) -> AbilityManager.handleCast(p, m.ability())));

        CHANNEL.registerMessage(id++, FlightToggle.class,
                (m, b) -> b.writeBoolean(m.enable()), b -> new FlightToggle(b.readBoolean()),
                toServer((p, m) -> FlightManager.set(p, m.enable())));

        CHANNEL.registerMessage(id++, Power.class,
                (m, b) -> b.writeInt(m.id()), b -> new Power(b.readInt()),
                toServer((p, m) -> Powers.power(p, m.id())));

        CHANNEL.registerMessage(id++, Rule.class,
                (m, b) -> {
                    b.writeInt(m.rule());
                    b.writeBoolean(m.value());
                },
                b -> new Rule(b.readInt(), b.readBoolean()),
                toServer((p, m) -> Powers.rule(p, m.rule(), m.value())));

        CHANNEL.registerMessage(id++, RunCommand.class,
                (m, b) -> b.writeUtf(m.command(), 1024), b -> new RunCommand(b.readUtf(1024)),
                toServer((p, m) -> Powers.command(p, m.command())));

        CHANNEL.registerMessage(id++, CommandBlockEdit.class,
                (m, b) -> {
                    b.writeInt(m.x());
                    b.writeInt(m.y());
                    b.writeInt(m.z());
                    b.writeUtf(m.command(), 1024);
                    b.writeInt(m.flags());
                },
                b -> new CommandBlockEdit(b.readInt(), b.readInt(), b.readInt(), b.readUtf(1024), b.readInt()),
                toServer((p, m) -> Powers.editCommandBlock(p, m.x(), m.y(), m.z(), m.command(), m.flags())));

        CHANNEL.registerMessage(id++, PassiveToggle.class,
                (m, b) -> b.writeInt(m.id()), b -> new PassiveToggle(b.readInt()),
                toServer((p, m) -> Passives.toggle(p, m.id())));

        CHANNEL.registerMessage(id++, Feedback.class,
                (m, b) -> {
                    b.writeInt(m.ability());
                    b.writeInt(m.status());
                    b.writeInt(m.value());
                },
                b -> new Feedback(b.readInt(), b.readInt(), b.readInt()),
                toClient(m -> ClientHooks.feedback(m.ability(), m.status(), m.value())));

        CHANNEL.registerMessage(id++, FlightState.class,
                (m, b) -> b.writeBoolean(m.on()), b -> new FlightState(b.readBoolean()),
                toClient(m -> ClientHooks.flight(m.on())));

        CHANNEL.registerMessage(id++, PassiveState.class,
                (m, b) -> b.writeInt(m.mask()), b -> new PassiveState(b.readInt()),
                toClient(m -> ClientHooks.passives(m.mask())));

        CHANNEL.registerMessage(id++, Adapt.class,
                (m, b) -> {
                    b.writeUtf(m.mob(), 256);
                    b.writeInt(m.level());
                },
                b -> new Adapt(b.readUtf(256), b.readInt()),
                toClient(m -> ClientHooks.adapt(m.mob(), m.level())));

        CHANNEL.registerMessage(id++, Notice.class,
                (m, b) -> {
                    b.writeUtf(m.text(), 512);
                    b.writeInt(m.rgb());
                },
                b -> new Notice(b.readUtf(512), b.readInt()),
                toClient(m -> ClientHooks.notice(m.text(), m.rgb())));
    }

    // ------------------------------------------------------------ helpers

    /** Send a message from the server to one player. */
    public static void send(ServerPlayer player, Object message) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), message);
    }

    /** Send a message from the client to the server. */
    public static void sendToServer(Object message) {
        CHANNEL.sendToServer(message);
    }

    /** Handler for client -> server messages: runs on the server thread with the sending player. */
    private static <T> BiConsumer<T, Supplier<NetworkEvent.Context>> toServer(BiConsumer<ServerPlayer, T> action) {
        return (msg, ctxSupplier) -> {
            NetworkEvent.Context ctx = ctxSupplier.get();
            ctx.enqueueWork(() -> {
                ServerPlayer sender = ctx.getSender();
                if (sender != null) action.accept(sender, msg);
            });
            ctx.setPacketHandled(true);
        };
    }

    /** Handler for server -> client messages: only ever runs on the client. */
    private static <T> BiConsumer<T, Supplier<NetworkEvent.Context>> toClient(Consumer<T> action) {
        return (msg, ctxSupplier) -> {
            NetworkEvent.Context ctx = ctxSupplier.get();
            ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> action.accept(msg)));
            ctx.setPacketHandled(true);
        };
    }
}
