package com.gameadmin.mod.client;

import com.gameadmin.mod.GameAdminMod;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Mod-bus client events: the key bindings. */
@Mod.EventBusSubscriber(modid = GameAdminMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientModEvents {
    public static final KeyMapping OPEN = new KeyMapping("key.gameadmin.open",
            InputConstants.Type.KEYSYM, 71, "key.categories.gameadmin");     // 71 = G
    public static final KeyMapping REPEAT = new KeyMapping("key.gameadmin.repeat",
            InputConstants.Type.KEYSYM, 86, "key.categories.gameadmin");     // 86 = V
    public static final KeyMapping FLY = new KeyMapping("key.gameadmin.fly",
            InputConstants.Type.KEYSYM, 72, "key.categories.gameadmin");     // 72 = H

    @SubscribeEvent
    public static void onRegisterKeys(RegisterKeyMappingsEvent event) {
        event.register(OPEN);
        event.register(REPEAT);
        event.register(FLY);
    }
}
