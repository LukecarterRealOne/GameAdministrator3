package com.gameadmin.mod;

import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** You are the game administrator. Press G for the Admin Console. */
@Mod(GameAdminMod.MOD_ID)
public class GameAdminMod {
    public static final String MOD_ID = "gameadmin";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public GameAdminMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        bus.addListener(this::commonSetup);
    }

    private void commonSetup(FMLCommonSetupEvent event) {
        event.enqueueWork(Net::register);
        LOGGER.info("Game Administrator loaded. You are in charge.");
    }
}
