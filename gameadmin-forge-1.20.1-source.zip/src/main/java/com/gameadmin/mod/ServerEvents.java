package com.gameadmin.mod;

import net.minecraft.server.MinecraftServer;
import net.minecraft.world.entity.Mob;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.server.ServerLifecycleHooks;

/** Forge event hooks that run on the server: the scheduler, passives, damage and cleanup. */
@Mod.EventBusSubscriber(modid = GameAdminMod.MOD_ID)
public final class ServerEvents {
    private ServerEvents() {}

    private static boolean cleaned = false;

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server == null) return;

        if (!cleaned) {          // remove effect entities left behind by a crash or a stopped server
            cleaned = true;
            WorldVfx.cleanup(server);
        }
        Scheduler.tick(server);
        Passives.tick(server);
    }

    /** Adaptation and Hazard Immunity: cancel the hit before any damage is taken. */
    @SubscribeEvent
    public static void onAttacked(LivingAttackEvent event) {
        if (!Passives.allowDamage(event.getEntity(), event.getSource(), event.getAmount())) {
            event.setCanceled(true);
        }
    }

    /** A mob frozen by Time Stop when the game was closed must not stay frozen forever. */
    @SubscribeEvent
    public static void onJoin(EntityJoinLevelEvent event) {
        if (event.getLevel().isClientSide()) return;
        if (event.getEntity() instanceof Mob mob && mob.getTags().contains(AbilityManager.FROZEN_TAG)
                && !AbilityManager.timeStopActive()) {
            mob.setNoAi(false);
            mob.removeTag(AbilityManager.FROZEN_TAG);
        }
    }
}
