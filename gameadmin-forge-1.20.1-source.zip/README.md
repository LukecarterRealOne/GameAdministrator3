# Game Administrator (Forge 1.20.1)

You are the **game administrator**. Press **G** for the Admin Console. **V** repeats your last ability, **H** toggles flight.
All keys can be changed under Controls -> Game Administrator.

Tabs in the console: **Abilities** (17), **Powers** (game modes, game rules, command line, survival command blocks), **Passives** (5).

## Abilities (they hit every living thing near you except yourself)
Smite, Blink, Time Warp, Weather, Full Restore, God Mode, Skyward, Freeze Field, Purge, Time Stop, Send: Nether / End / Overworld,
Overdrive, Omniscience, Zero-G, **Black Hole**.

## Two layers of VFX, zero particles
1. **Screen VFX** (only the caster): flashes, vignettes, streaks, scanlines, glitch bars on the HUD.
2. **World VFX** (everyone nearby, server-side): glowing block-display entities (rings, beams, bubbles, columns, a spinning
   black hole) plus a sound for every ability.

If world effects ever do not appear, search `logs/latest.log` for `Command rejected by the parser` and send those lines.

## Powers tab
- Game mode buttons, ON/OFF for Keep Inv., Mob Grief, Day Cycle, Weather, Fall Dmg, Fire Dmg, Insta-Respawn, Mob Spawn.
- **Command Line**: run any command in survival, with or without cheats.
- **Command blocks in survival**: "Get Command Blocks", place one, then right-click it (not sneaking) for an editor.

## Passives
Hazard Immunity, **Adaptation** (learns from ANY damage: mobs, players, lava, fire, falls... level 5 = 100% dodge; top-left badge),
Night Eyes, Never Hungry, Regeneration.

## Differences from the Fabric 26.1 version (Minecraft 1.20.1 limits)
- **Time Stop** has no `/tick freeze` in 1.20.1, so it switches the AI off for every mob within 64 blocks for 8 seconds instead.
  (Frozen mobs are tagged so they can never stay frozen if you quit mid-freeze.)
- Game rules use the old camelCase names. The "Cmd Blocks" rule does not exist in 1.20.1 (command blocks are controlled by
  `enable-command-block` in server.properties; single player always allows them), so that slot is "Mob Spawn".

## Who can use the powers?
Single player / LAN: everyone in the world. Dedicated servers: only names listed (one per line) in `config/gameadmin-admins.txt`.

## Install
Minecraft **1.20.1**, **Forge 47.3.0+**, Java 17. Put the jar in `mods/`. For multiplayer, install on server and clients.

## Build on GitHub
Upload this folder to a NEW repo. Actions tab -> "Build mod" -> download the `gameadmin-1.20.1-forge` artifact.
(This uses the same build setup that already worked for your Imagination mod.)
